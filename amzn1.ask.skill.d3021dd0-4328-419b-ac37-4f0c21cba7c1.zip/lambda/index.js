"use strict";

const https = require("https");
const { URL } = require("url");

const BRIDGE_BASE_URL = "https://proconscription-nonviolative-jenny.ngrok-free.dev";

// metti false quando hai finito di debug
const DEBUG_MODE = false;

function speak(text, endSession = false) {
  return {
    version: "1.0",
    response: {
      outputSpeech: { type: "PlainText", text },
      shouldEndSession: Boolean(endSession),
    },
  };
}

function slotValue(slot) {
  return (slot?.value ?? "").toString().trim();
}

function debugIntent(req) {
  const intentName = req?.intent?.name || "NO_INTENT";
  const slots = req?.intent?.slots || {};
  const slotPairs = Object.keys(slots)
    .map((k) => `${k}=${slots[k]?.value ?? ""}`)
    .join(", ");
  return `DEBUG: intent=${intentName}. slots: ${slotPairs || "nessuno"}`;
}

/**
 * POST JSON al bridge (HTTPS nativo, compatibile con Alexa runtime)
 */
function postJson(path, body) {
  return new Promise((resolve, reject) => {
    const url = new URL(BRIDGE_BASE_URL + path);
    const data = JSON.stringify(body ?? {});

    const options = {
      hostname: url.hostname,
      port: 443,
      path: url.pathname,
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(data),
      },
    };

    console.log("➡️ Calling bridge:", BRIDGE_BASE_URL + path, body);

    const req = https.request(options, (res) => {
      let raw = "";
      res.on("data", (chunk) => (raw += chunk));
      res.on("end", () => {
        let json = null;
        try {
          json = JSON.parse(raw);
        } catch {}

        const ok = res.statusCode >= 200 && res.statusCode < 300;
        if (!ok) {
          const msg = json?.error || `HTTP ${res.statusCode}`;
          return reject(new Error(msg));
        }

        resolve(json ?? raw);
      });
    });

    req.on("error", (err) => reject(err));
    req.write(data);
    req.end();
  });
}

exports.handler = async (event) => {
  try {
    const req = event.request;

    // --- Launch
    if (req.type === "LaunchRequest") {
      return speak("Dimmi un comando: accendi faro ovest, oppure apri cucina finestra sud.", false);
    }

    // --- Intents
    if (req.type === "IntentRequest") {
      const name = req.intent?.name || "";

      if (DEBUG_MODE) {
        console.log("🧪", debugIntent(req));
      }

      // Fallback
      if (name === "AMAZON.FallbackIntent") {
        const msg =
          "Non ho capito. Prova: accendi faro ovest, spegni faro ovest, apri bagno p1 finestra.";
        if (DEBUG_MODE) return speak(`${debugIntent(req)}. ${msg}`, false);
        return speak(msg, false);
      }

      // Help
      if (name === "AMAZON.HelpIntent") {
        return speak("Puoi dire: accendi faro ovest, spegni faro ovest, apri cucina finestra sud.", false);
      }

      // Stop/Cancel
      if (name === "AMAZON.StopIntent" || name === "AMAZON.CancelIntent") {
        return speak("Ok.", true);
      }

      // ON/OFF
      if (name === "TurnOnIntent" || name === "TurnOffIntent") {
        const dispositivo = slotValue(req.intent.slots?.dispositivo);
        if (!dispositivo) {
          if (DEBUG_MODE) return speak(`${debugIntent(req)}. Quale dispositivo?`, false);
          return speak("Quale dispositivo?", false);
        }

        const on = name === "TurnOnIntent";

        await postJson("/device/power", { name: dispositivo, on });

        const spoken = `${on ? "Accendo" : "Spengo"} ${dispositivo}.`;
        if (DEBUG_MODE) return speak(`${debugIntent(req)}. ${spoken}`, true);
        return speak(spoken + " Altro comando?", false);

      }

      // BLINDS
      if (name === "OpenBlindIntent" || name === "CloseBlindIntent") {
        const tapparella = slotValue(req.intent.slots?.tapparella);
        if (!tapparella) {
          if (DEBUG_MODE) return speak(`${debugIntent(req)}. Quale tapparella?`, false);
          return speak("Quale tapparella?", false);
        }

        const value = name === "OpenBlindIntent" ? 100 : 0;

        await postJson("/blind/set", { name: tapparella, value });

        const spoken = `${name === "OpenBlindIntent" ? "Apro" : "Chiudo"} ${tapparella}.`;
        if (DEBUG_MODE) return speak(`${debugIntent(req)}. ${spoken}`, true);
        return speak(spoken + " Altro comando?", false);
      }

      // Unhandled intent
      if (DEBUG_MODE) return speak(`${debugIntent(req)}. Comando non riconosciuto.`, false);
      return speak("Comando non riconosciuto.", false);
    }

    return speak("Non ho capito.", false);
  } catch (e) {
    console.log("❌ Error:", e);
    return speak(`Errore: ${e.message}`, true);
  }
};
